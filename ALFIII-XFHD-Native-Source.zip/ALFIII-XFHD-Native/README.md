# ALFIII XFHD Native

Aplikasi Android minimal yang hanya membawa metode HQ lokal dari APK yang dianalisis. Bagian yang dipakai ulang secara perilaku adalah perintah FFmpeg yang tertanam di bundle:

```text
-vf "minterpolate=fps=120:mi_mode=blend" -c:v mpeg4 -qscale:v 2 -c:a copy
```

Tidak ada API, login, downloader, Telegram, atau endpoint Kuronai.

## Build
Buka folder ini di Android Studio, tunggu Gradle sync, lalu Build > Build APK(s). Dependency FFmpegKit diambil dari Maven Central.

Output diproses lokal ke folder aplikasi. Android 11+ bisa membagikan hasil melalui tombol Bagikan.
