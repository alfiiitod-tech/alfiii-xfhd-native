package com.alfiii.xfhd;

import android.app.*;import android.os.*;import android.content.*;import androidx.core.content.FileProvider;import android.database.Cursor;import android.net.Uri;import android.provider.OpenableColumns;import android.view.*;import android.widget.*;import java.io.*;import com.arthenica.ffmpegkit.*;

public class MainActivity extends Activity {
  TextView status, picked; Button choose, process, share; Uri selected; File input, output;
  int pink=android.graphics.Color.rgb(254,44,85), cyan=android.graphics.Color.rgb(37,244,238);
  public void onCreate(Bundle b){super.onCreate(b); buildUi();}
  TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(android.graphics.Color.WHITE);t.setTextSize(size);t.setPadding(0,8,0,8);return t;}
  public void buildUi(){ LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,26,28,24);root.setBackgroundColor(android.graphics.Color.rgb(9,9,11));
    TextView title=tv("ALFIII XFHD",22);title.setTypeface(null,1);title.setTextColor(cyan);root.addView(title);
    TextView sub=tv("Native HQ method • local processing",13);sub.setTextColor(0xffa0a0ad);root.addView(sub);
    picked=tv("Belum ada video dipilih",15);picked.setPadding(0,40,0,40);root.addView(picked);
    choose=new Button(this);choose.setText("PILIH VIDEO");root.addView(choose,new LinearLayout.LayoutParams(-1,58));
    process=new Button(this);process.setText("PROSES HQ METHOD");process.setEnabled(false);root.addView(process,new LinearLayout.LayoutParams(-1,58));
    status=tv("Metode: minterpolate 120 FPS + MPEG-4 QScale 2",12);status.setTextColor(0xffa0a0ad);root.addView(status);
    share=new Button(this);share.setText("BAGIKAN HASIL");share.setVisibility(View.GONE);root.addView(share,new LinearLayout.LayoutParams(-1,58));
    setContentView(root);
    choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,9);});
    process.setOnClickListener(v->runHQ()); share.setOnClickListener(v->{if(output!=null){Intent i=new Intent(Intent.ACTION_SEND);i.setType("video/mp4");i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,"com.alfiii.xfhd.fileprovider",output));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Bagikan video"));}});
  }
  protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==9&&c==RESULT_OK&&d!=null){selected=d.getData();picked.setText("Video: "+name(selected));process.setEnabled(true);}}
  String name(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);try{if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)return c.getString(x);}}finally{if(c!=null)c.close();}return "video";}
  void runHQ(){process.setEnabled(false);choose.setEnabled(false);share.setVisibility(View.GONE);status.setText("Menyalin video ke ruang kerja…");new Thread(()->{try{input=new File(getCacheDir(),"alfiii_input.mp4");try(InputStream in=getContentResolver().openInputStream(selected);OutputStream out=new FileOutputStream(input)){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);}output=new File(getExternalFilesDir(null),"ALFIII_XFHD_HQ.mp4");String cmd="-y -i "+q(input.getAbsolutePath())+" -vf "+q("minterpolate=fps=120:mi_mode=blend")+" -c:v mpeg4 -qscale:v 2 -c:a copy "+q(output.getAbsolutePath());runOnUiThread(()->status.setText("Memproses HQ method…"));FFmpegKit.executeAsync(cmd,s->{boolean ok=ReturnCode.isSuccess(s.getReturnCode());runOnUiThread(()->{process.setEnabled(true);choose.setEnabled(true);if(ok){status.setText("Selesai: "+output.getAbsolutePath());share.setVisibility(View.VISIBLE);}else status.setText("Gagal memproses. Coba video MP4 yang lebih kecil.");});});}catch(Exception e){runOnUiThread(()->{process.setEnabled(true);choose.setEnabled(true);status.setText("Gagal membaca video: "+e.getMessage());});}}).start();}
  String q(String s){return "\""+s.replace("\"","\\\"")+"\"";}
}
